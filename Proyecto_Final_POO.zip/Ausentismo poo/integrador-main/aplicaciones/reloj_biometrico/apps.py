from django.apps import AppConfig


class RelojBiometricoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aplicaciones.reloj_biometrico'
