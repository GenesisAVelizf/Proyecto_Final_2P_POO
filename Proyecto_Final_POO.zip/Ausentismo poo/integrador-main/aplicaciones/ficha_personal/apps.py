from django.apps import AppConfig


class FichaPersonalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aplicaciones.ficha_personal'
