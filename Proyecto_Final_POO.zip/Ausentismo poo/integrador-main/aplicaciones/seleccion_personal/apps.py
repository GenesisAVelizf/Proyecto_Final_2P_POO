from django.apps import AppConfig


class SeleccionPersonalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aplicaciones.seleccion_personal'
